/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author jessw
 */
public class AccessLog {
    
    private long userId;
    private long startTime;
    private long endTime;
    
    public AccessLog(long userId, long startTime, long endTime)  {
        this.userId = userId;
        this.startTime = startTime;
        this.endTime = endTime;
    }
    
    public AccessLog getlog(){
        return this;
    }
    
    public long getId(){
        return userId;
    }
    
    public long getStartTime(){
        return startTime;
    }
    
    public long getEndTime(){
        return endTime;
    }
}
