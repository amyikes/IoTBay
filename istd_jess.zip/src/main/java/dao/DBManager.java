package dao;

import model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

/* 
* DBManager is the primary DAO class to interact with the database. 
*/

public class DBManager {

    private Statement st;
    private Connection connection;
    private LinkedList<AccessLog> logs;
    private LinkedList<Product> products;

    public DBManager(Connection conn) throws SQLException {
        this.connection = conn;
        st = this.connection.createStatement();
    }
    // Method to retrieve all customers from the database
    public List<User> getUsersbyRole(String role) {
        List<User> users = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM Users WHERE UserRole = ?");
            statement.setString(1, role);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                long userID = resultSet.getLong("UserID");
                String firstName = resultSet.getString("First_Name");
                String lastName = resultSet.getString("Last_Name");
                String email = resultSet.getString("Email");
                String password = resultSet.getString("Password");
                int phoneNumber = resultSet.getInt("Phone_Number");

                User user = new User(userID, firstName, lastName, email, password, phoneNumber, role);
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    // Method to retrieve a user by ID from the database
    public User getUserByID(long userID) {
        User user = null;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM Users WHERE UserID = ?");
            statement.setLong(1, userID);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String firstName = resultSet.getString("First_Name");
                String lastName = resultSet.getString("Last_Name");
                String email = resultSet.getString("Email");
                String password = resultSet.getString("Password");
                int phoneNumber = resultSet.getInt("Phone_Number");
                String role = resultSet.getString("UserRole");

                user = new User(userID, firstName, lastName, email, password, phoneNumber, role);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
    
    // Method to see if a user exists by email 
    public User getUserByEmail(String Email) {
        User user = null;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM Users WHERE Email = ?");
            statement.setString(1, Email);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                long userID = resultSet.getLong("UserID");
                String firstName = resultSet.getString("First_Name");
                String lastName = resultSet.getString("Last_Name");
                String email = resultSet.getString("Email");
                String password = resultSet.getString("Password");
                int phoneNumber = resultSet.getInt("Phone_Number");
                String role = resultSet.getString("UserRole");

                user = new User(userID, firstName, lastName, email, password, phoneNumber, role);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
    
    // Method to see if a user exists by password 
    public User getUserByPassword(String password) {
        User user = null;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM Users WHERE Email = ? and Password = ?");
            statement.setString(1, password);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                long userID = resultSet.getLong("UserID");
                String firstName = resultSet.getString("First_Name");
                String lastName = resultSet.getString("Last_Name");
                String email = resultSet.getString("Email");
                int phoneNumber = resultSet.getInt("Phone_Number");
                String role = resultSet.getString("UserRole");

                user = new User(userID, firstName, lastName, email, password, phoneNumber, role);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    // Method to save a new user to the database
    public void saveUser(User user) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Users (UserID, First_Name, Last_Name, Password, Phone_Number, UserRole) VALUES (?, ?, ?, ?, ?, ?)");
            statement.setLong(1, System.currentTimeMillis()); // Set UserID as current time
            statement.setString(2, user.getFirstName());
            statement.setString(3, user.getLastName());
            statement.setString(4, user.getPassword());
            statement.setInt(5, user.getPhoneNumber());
            statement.setString(6,user.getUserRole());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to update an existing user in the database
    public void updateUser(User user) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE Users SET First_Name = ?, Last_Name = ?, Email = ?, Password = ?, Phone_Number = ? WHERE UserID = ?");
            statement.setString(1, user.getFirstName());
            statement.setString(2, user.getLastName());
            statement.setString(3, user.getEmail());
            statement.setString(4, user.getPassword());
            statement.setInt(5, user.getPhoneNumber());
            statement.setLong(6, user.getUserId());

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete a user from the database
    public void deleteUser(long userID) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM Users WHERE UserID = ?");
            statement.setLong(1, userID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void addAccessLog(long userId, long startTime, long endTime){
        AccessLog aL = new AccessLog(userId,startTime,endTime);
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO AccessLogs (UserId, loginTime, logoutTime) VALUES (?, ?, ?)");
            statement.setLong(1, aL.getId()); 
            statement.setLong(2, aL.getStartTime());
            statement.setLong(3, aL.getEndTime());
            statement.executeUpdate();
            logs.add(aL);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public LinkedList<AccessLog> viewLogs(){
        return logs; //sad ver
    }
    
    // Method to retrieve all logs from the database
    public List<AccessLog> getLogByDate(int date) {
        List<AccessLog> logs = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM AccessLogs WHERE LoginTime = ?");
            statement.setInt(1, date);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                long userId = resultSet.getLong("UserID");
                long startTime = resultSet.getLong("StartTime");
                long endTime = resultSet.getLong("EndTime");

                AccessLog aL = new AccessLog(userId,startTime,endTime);
                logs.add(aL);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return logs;
    }
    
    public void addproduct(long productId, String description, int stocklevel, String price){
        Product p = new Product(productId,description,stocklevel,price);
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Products (ProductId, ProductDescription, StockLevel, Price) VALUES (?, ?, ?, ?, ?)");
            statement.setLong(1, p.getId()); 
            statement.setString(2, p.getDescription());
            statement.setLong(3, p.getStocklevel());
            statement.setString(4, p.getPrice());
            statement.executeUpdate();
            products.add(p);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public LinkedList<Product> viewProducts(){
        return products;
    }
    
    // Method to update an existing product in the database
    public void updateProduct(Product p) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE Product SET ProductDescription = ?, StockLevel = ?, Price = ? WHERE ProductID = ?");
            statement.setString(1, p.getDescription());
            statement.setInt(2, p.getStocklevel());
            statement.setString(3, p.getPrice());
            statement.setLong(4, p.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Method to delete a product from the database
    public void deleteProduct(long ProductID) {
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM Product WHERE ProductID = ?");
            statement.setLong(1, ProductID);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Method to retrieve all products from the database
    public List<Product> getProducts() {
        List<Product> products = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM Products");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                long ProductID = resultSet.getLong("ProductID");
                String description = resultSet.getString("Description");
                int stockLevel = resultSet.getInt("StockLevel");
                String price = resultSet.getString("Price");
                Product p = new Product(ProductID, description, stockLevel, price);
                products.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
    
    
}  
    
