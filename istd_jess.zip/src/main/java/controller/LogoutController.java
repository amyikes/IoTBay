package controller;

 
import java.io.IOException;
import java.sql.SQLException;

import java.util.logging.Level;

import java.util.logging.Logger;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.http.HttpSession;
import java.sql.Connection;

import model.*;
import java.sql.*;

import dao.DBManager;
        
import jakarta.servlet.annotation.WebServlet;
@WebServlet("/logout")

public class LogoutController extends HttpServlet{
    
    @Override   

    protected void doPost(HttpServletRequest request, HttpServletResponse response)   throws ServletException, IOException {       
                  
                HttpSession session = request.getSession();
                DBManager db;
                db = (DBManager) session.getAttribute("manager");
                long userId = (long) session.getAttribute("userId");
                db.addAccessLog(userId, session.getCreationTime(), session.getLastAccessedTime());
                // Close the connection and remove it from the session
                Connection connection = (Connection)session.getAttribute("connection");
                try { 
                    connection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(LogoutController.class.getName()).log(Level.SEVERE, null, ex);
                }
                session.invalidate(); ///not sure which of these 2 to use, if it breaks delete one, or the other?
                session.removeAttribute("connection");
                //out.println("You have been logged out."); display on page?
                
    }
    
}
