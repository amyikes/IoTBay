package controller;
 
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.Connection;
import model.*;
import java.sql.*;
import dao.DBManager;        
import jakarta.servlet.annotation.WebServlet;
@WebServlet("/productEdit")

public class ProductController extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)   throws ServletException, IOException {       
                  
                HttpSession session = request.getSession();
                DBManager db;
                db = (DBManager) session.getAttribute("manager");
                Connection connection = (Connection)session.getAttribute("connection");
                String msg = (String) request.getSession().getAttribute("message");
                Product p;
                if(msg.equals("update")){
                    //
                } else if(msg.equals("add")){
                    //
                } else if(msg.equals("delete")){
                    //
                }
                
                
                
    
    }
}