package controller;

 
import java.io.IOException;
import java.sql.SQLException;

import java.util.logging.Level;

import java.util.logging.Logger;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.http.HttpSession;
import java.sql.Connection;

import model.User;

import dao.DBManager;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/login")
 

public class LoginController extends HttpServlet {
   

     @Override   

     protected void doPost(HttpServletRequest request, HttpServletResponse response)   throws ServletException, IOException {       
                  
                HttpSession session = request.getSession();
                Validator val = new Validator();
                String em = (String) session.getAttribute("email");
                String p = (String) session.getAttribute("pword");
                DBManager db;
                //Connection connection = (Connection) session.getAttribute("connection");
                //db = new DBManager(connection);
                db = (DBManager) session.getAttribute("manager");
                User user = null;
                User userE = db.getUserByEmail(em);
                User userP = db.getUserByPassword(p);
                if(userE != null && userP != null){
                    user = userE;
                }
                if(val.checkEmpty(em, p)){
                    String message = "Please enter all login info";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");
                }
                else if (!val.validateEmail(em)) {       //if email pattern is incorrect
                    String message = "Incorrect Email Format";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");
                    
                    //8-set incorrect email error to the session
                    
                    //9- redirect user back to the login.jsp
                    
                } else if ( !val.validatePassword(p) && userE!=null) {  //if password pattern is correct but wrong password
                    String message = "Incorrect Password Format";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");
                    //11-set incorrect password error to the session
                    
                    //12- redirect user back to the login.jsp
                    
                } else if (user != null) {
                    
                    
                    
                    
                    //13-save the logged in user object to the session
                    
                    //14- redirect user to the main.jsp
                    
                } else {
                    String message = "user does not exist";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");
                    //15-set user does not exist error to the session
                    
                    //16- redirect user back to the login.jsp
                    
                }
                
            

        }
}

