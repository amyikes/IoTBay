package controller;

 
import java.io.IOException;
import java.sql.SQLException;

import java.util.logging.Level;

import java.util.logging.Logger;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;

import jakarta.servlet.http.HttpServletRequest;

import jakarta.servlet.http.HttpServletResponse;

import jakarta.servlet.http.HttpSession;
import java.sql.Connection;

import model.User;

import dao.DBManager;
@WebServlet("/register")

public class RegisterController extends HttpServlet {
    @Override   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   throws ServletException, IOException {       
        request.getRequestDispatcher("/WEB-INF/products.jsp").forward(request, response);    
        try {       
                HttpSession session = request.getSession();
                Validator val = new Validator();
                DBManager db;
                Connection connection = (Connection) session.getAttribute("connection");
                db = new DBManager(connection);
                String fn = (String) session.getAttribute("First_Name");
                String ln = (String) session.getAttribute("Last_Name");
                String e = (String) session.getAttribute("email");
                String p = (String) session.getAttribute("pword");
                int pn = (Integer) session.getAttribute("phone_number");
                if (!val.validateEmail(e)) {       //if email pattern is incorrect
                    String message = "Incorrect Email Format";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");    
                } else if ( !val.validatePassword(p)) {  //if password pattern is correct but wrong password
                    String message = "Incorrect Password Format";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");
                } else if (!val.validateName(fn) || !val.validateName(ln)) {
                    String message = "Incorrect Name Format";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");       
                } else {
                    String message = "user does not exist";
                    request.getSession().setAttribute("message", message);
                    response.sendRedirect("register.jsp");
                    User user = new User(-1,fn,ln,e,p,pn,"Customer"); //-1 is show it hasn't been set yet  
                    db.saveUser(user);
                }
                
                
                
                
                
            } catch (SQLException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
}
